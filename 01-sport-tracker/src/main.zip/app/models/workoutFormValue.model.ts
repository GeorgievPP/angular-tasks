export interface WorkoutFormValue {
  workout: string;
  location: string;
  date: string;
}
